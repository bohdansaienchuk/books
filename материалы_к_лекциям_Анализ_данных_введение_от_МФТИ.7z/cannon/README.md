# cannon
Набросок игры "Пушка"

Реализация ООП.


Ссылка на старую игру пушка: http://judge.mipt.ru/mipt_cs_on_python3_2016/labs/lab10.html#id4
